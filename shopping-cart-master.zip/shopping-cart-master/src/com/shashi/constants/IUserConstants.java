package com.shashi.constants;

public interface IUserConstants {

	public String TABLE_USER = "user";
	public String COLUMN_NAME = "name";
	public String COLUMN_MOBILE = "mobile";
	public String COLUMN_EMAIL = "email";
	public String COLUMN_ADDRESS = "address";
	public String COLUMN_PINCODE = "pincode";
	public String COLUMN_PASSWORD = "password";
}
